# campaign
pagina de campañas de Tesoros de Dios

Se administra la pagina por medio del subdominio.tesorosdedios.org/Admin/ingreso
los usuarios se deben de asignar y se puede realizar las siguientes acciones

1. editar el encabezado de la campaña, esto es el titulo y tambien su descripcion
2. se pueden agregar las imagenes y las secciones de los articulos segun se estimen convenientes.

todo lo que se modifique en esta parte administrativa, puede tener efecto en la parte visual de la presentacion