<header class="">
   <!-- se carga desde la carpeta de controlador en tituloC -->
   <?php
      //se carga desde la carpeta de controlador en tituloC
      $verEncabezado = new tituloclassC();
      $verEncabezado -> obtenerTituloC();
   ?>

      <!-- <ul class="nav">
        <li><a href="../index.html" title="">Home</a></li>
        <li><a href="../about.html" title="">About</a></li>
        <li><a href="../services.html" title="">Services</a></li>
        <li><a href="../contact.html" title="">Contact</a></li>
        <li><a href="../components.html" title="">Components</a></li>
      </ul> -->

      <nav class="nav-footer">
        <p class="nav-footer-social-buttons">
          <a class="fa-icon" href="https://www.instagram.com/tesorosdedios" title="Instagram">
            <i class="fa fa-instagram"></i>
          </a>
          <a class="fa-icon" href="https://facebook.com/tesorosdediosni" title="Facebook">
            <i class="fa fa-facebook"></i>
          </a>
          <a class="fa-icon" href="https://twitter.com/tesorosdediosni" title="Twitter">
            <i class="fa fa-twitter"></i>
          </a>
          <a class="fa-icon" href="https://www.youtube.com/channel/UCb51xiHzozNL4SRvntxx4xA" title="YouTube">
            <i class="fa fa-youtube"></i>
          </a>
        </p>
        <p>Camapañas de <a href="http://www.tesorosdedios.org/" title="Tesoros de Dios">Tesoros de Dios</a></p>
      </nav>  
    </div> 
  </nav>
</header>