
<main class="" id="main-collapse">
<!-- Add your site or app content here -->
<div class="hero-full-wrapper">
  <div class="grid">
  <div class="gutter-sizer"></div>
    <div class="grid-sizer"></div>
    
  <?php
    $obtenerSecciones = new seccionclassC();
    $obtenerSecciones -> obtenerSeccionC();
  ?>

    <!-- <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-12.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    
    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-05.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Cantidad Total = 0</p>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-13.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-04.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>
    
    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-07.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-11.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-10.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div>

    <div class="grid-item">
      <img class="img-responsive" alt="" src="vista/assets/images/img-03.jpg">
      <a href="../project.html" class="project-description">
        <div class="project-text-holder">
          <div class="project-text-inner">
            <h3>Vivamus vestibulum</h3>
            <p>Discover more</p>
          </div>
        </div>
      </a>
    </div> -->
    
  </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function (event) {
       masonryBuild();
    });
</script>
  
</main>
