<?php
      // en variables
      // $databaseName = "tesorosd_bdbibliotecatdd";
      // $servidor = "localhost";
      // $user = "tesorosd_library";
      // $passw = "yOLtH_qK?8gt";

      //conexion en local
      $databaseName = "bdcampaign";
      $servidor = "localhost";
      $user = "root";
      $passw = "";
?>