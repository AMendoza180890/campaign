<?php
class plantillaAdminLteC{
    public function llamarPlantillaAdminLte(){
        include 'vista/plantilla.php';
    }
}
?>