<?php
    $rutasAdmin = [
        'inicio' => "inicio" , 
        'catusuarios' => "catusuarios" , 
        'login' => "login" , 
        'salir' => "salir" , 
        'titulo' => 'titulo',
        'catseccion'=> 'catseccion'
    ]
?>