<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <ul class="sidebar-menu" data-widget="tree">
            <li>
                <a href="inicio">
                    <i class="fa fa-home"></i>
                    <span>Inicio</span>
                </a>
            </li>
            <li>
                <a href="titulo">
                    <i class="fa fa-header"></i>
                    <span>Titulo</span>
                </a>
            </li>
            <li>
                <a href="catseccion">
                    <i class="fa fa-align-justify"></i>
                    <span>Secciones</span>
                </a>
            </li>
            <li>
                <a href="catusuarios">
                    <i class="fa fa-user"></i>
                    <span>Usuarios</span>
                </a>
            </li>
            <!--<li>
                <a href="#">
                    <i class="fa fa-home"></i>
                    <span>Opcion 3</span>
                </a>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-list-ul"></i>
                    <span>Desplegable</span>

                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="#">
                            <span>opcion 1</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span>opcion 2</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-home"></i>
                    <span>Mensajes</span>
                </a>
            </li> -->


        </ul>

    </section>
    <!-- /.sidebar -->
</aside>